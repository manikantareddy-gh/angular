package venpras.tech.enums;

public enum BookStatus {
    REQ,APP,REJ
}
