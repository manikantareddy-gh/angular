package venpras.tech.exceptions;

public class NoBooksAvailableException extends Exception {
    public NoBooksAvailableException(String message) {
        super(message);
    }
}
