package venpras.tech.exceptions;

public class InvalidBookException extends Exception {
    public InvalidBookException(String message) {
        super(message);
    }
}
