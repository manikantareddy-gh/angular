package venpras.tech.exceptions;

public class NoRequestsAvailableException extends Exception {
    public NoRequestsAvailableException(String message) {
        super(message);
    }
}
