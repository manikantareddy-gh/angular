import { Component } from '@angular/core';

@Component({
  selector: 'app-librarian',
  imports: [],
  templateUrl: './librarian.html',
  styleUrl: './librarian.css'
})
export class Librarian {

}
