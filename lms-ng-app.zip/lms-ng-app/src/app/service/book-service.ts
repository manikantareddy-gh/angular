import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private httpClient: HttpClient) { }

  baseUrl: String = "/api";

  getBooks() {
    return this.httpClient.get<any>(this.baseUrl + "/books");
  }
  postRequest(body: any) {
    return this.httpClient.post<any>(this.baseUrl + "/student/request", body)
  }
  deleteRequest(body: any) {
    return this.httpClient.request<any>('delete', this.baseUrl + "/reject/request", {
      body: body
    });
  }
  acceptRequest(body: any) {
    return this.httpClient.post<any>(this.baseUrl + "/request/accept", body);
  }
}
