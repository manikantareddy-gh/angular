export interface IBook{
    id:number;
    title:String;
    author:String;
}