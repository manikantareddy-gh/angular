export interface IResponse {
    status: String;
    message: String;
    data: any;
}