import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  baseurl: string = '/api';
  constructor(private http: HttpClient) {}
    getBooks(){
      return this.http.get(this.baseurl+"/admin/employees/tickets");
    }


}


