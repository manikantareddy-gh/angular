import { AbstractControl } from "@angular/forms";

export function reqAgeValidator(control: AbstractControl) {
    if(control.value >=1 && control.value < 18) {
        return { 'reqAge': true }; 
    }else{
        return null;
    }
}

