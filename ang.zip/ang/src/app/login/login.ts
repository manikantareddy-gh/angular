import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { nospaceValidator } from '../validators/no-space-validator';
import { reqAgeValidator } from '../validators/reqage-validator';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  //here i called the method which i created in the html file for submitting the form
  showValues() {
    // Use form control to get the value of the form
    if (this.myForm.valid) {
      console.log(this.myForm.value);
    } else {
      console.log('Form is invalid');
    }
  }
  // intially i created the form with the help of form group and form control
  // i used the form control for username and password
  // i used the validators for username to make it required
  // and minimum length of 4 characters
  // i used the validators for password to make it maximum length of 4 characters
  myForm = new FormGroup({
    username: new FormControl('', [Validators.required, Validators.minLength(4)]),
    password: new FormControl('', [Validators.maxLength(4), Validators.required, nospaceValidator]),
    gender: new FormControl('', Validators.required),
    age: new FormControl('', [Validators.required,reqAgeValidator]),
  });
}
